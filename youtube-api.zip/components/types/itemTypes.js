export const itemTypes = {
    BOX: 'box',
  }
  