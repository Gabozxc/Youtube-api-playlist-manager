
import SearchXscroll from "./SearchXscroll";

export default function PlayListHome() {
  return (
          <SearchXscroll />
  );
}
