"use strict";
(() => {
var exports = {};
exports.id = 672;
exports.ids = [672];
exports.modules = {

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 614:
/***/ ((module) => {

module.exports = require("next-auth/jwt");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_jwt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(614);
/* harmony import */ var next_auth_jwt__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_jwt__WEBPACK_IMPORTED_MODULE_2__);



const secret = process.env.SECRET;
let accessToken;
let idVideo;
let idPlaylist;
const addYoutubeVideoPlaylist = async ()=>{
    //PlaylistItems API request to add video to a playlist
    const url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&key=${process.env.YOUTUBE_API_KEY}`;
    const datas = {
        snippet: {
            playlistId: idPlaylist,
            resourceId: {
                kind: "youtube#video",
                videoId: idVideo
            }
        }
    };
    const options = {
        method: "POST",
        url: url,
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        data: datas
    };
    const data = await axios__WEBPACK_IMPORTED_MODULE_0___default()(options);
    if (data === null || data === void 0 ? void 0 : data.nextPageToken) {
        return data.items.concat(await addYoutubeVideoPlaylist(data.nextPageToken));
    }
    return data.items;
};
const requestYoutube = async (req, res)=>{
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.getSession)({
        req
    });
    idVideo = req.body.idVideo;
    idPlaylist = req.body.idPlaylist;
    if (!session) {
        return res.status(401).end();
    }
    const token = await (0,next_auth_jwt__WEBPACK_IMPORTED_MODULE_2__.getToken)({
        req,
        secret,
        encryption: true
    });
    accessToken = token.accessToken;
    const data = await addYoutubeVideoPlaylist();
    res.status(200).json(data);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (requestYoutube);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1210));
module.exports = __webpack_exports__;

})();