"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
// EXTERNAL MODULE: ./types/typesYT.js
var typesYT = __webpack_require__(4149);
;// CONCATENATED MODULE: ./reducers/youtubeApi.js

const initialState = {
    playlistItems: false,
    playLists: [],
    loading: false,
    logIn: false,
    message: ""
};
const stateYoutubeApi = (state = initialState, action)=>{
    switch(action.type){
        case typesYT/* DOWNLOADING_DATA */.yY:
            return {
                ...state,
                loading: true,
                logIn: true
            };
        case typesYT/* DOWNLOADING_DATA_SUCCESS */.u3:
            return {
                ...state,
                loading: false,
                playLists: action.payload
            };
        case typesYT/* DOWNLOADING_DATA_FAILURE */.V3:
            return {
                ...state,
                loading: false,
                logIn: false,
                message: action.payload
            };
        case typesYT/* CREATING_PLAYLIST */.bB:
            return {
                ...state,
                loading: true
            };
        case typesYT/* CREATING_PLAYLIST_SUCCESS */.ke:
            return {
                ...state,
                loading: false,
                playLists: [
                    action.payload,
                    ...state.playLists
                ]
            };
        case typesYT/* CREATING_PLAYLIST_FAILURE */.ar:
            return {
                ...state,
                loading: false,
                message: action.payload
            };
        case typesYT/* DELETING_PLAYLIST */.B1:
            return {
                ...state,
                loading: true
            };
        case typesYT/* DELETING_PLAYLIST_SUCCESS */.vG:
            return {
                ...state,
                loading: false,
                playLists: state.playLists.filter((playlist)=>playlist.id !== action.payload
                )
            };
        default:
            return state;
    }
};
/* harmony default export */ const youtubeApi = (stateYoutubeApi);

;// CONCATENATED MODULE: ./reducers/index.js


const rootReducer = (0,external_redux_namespaceObject.combineReducers)({
    youtubeApi: youtubeApi
});
/* harmony default export */ const reducers = (rootReducer);

;// CONCATENATED MODULE: ./store.js



const store = (0,external_redux_namespaceObject.createStore)(reducers, (0,external_redux_namespaceObject.compose)((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default())),  false ? 0 : (f)=>f
));
/* harmony default export */ const store_0 = (store);

;// CONCATENATED MODULE: ./pages/_app.js





function MyApp({ Component , pageProps: { session , ...pageProps }  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.SessionProvider, {
        session: session,
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
            store: store_0,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    }));
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yY": () => (/* binding */ DOWNLOADING_DATA),
/* harmony export */   "u3": () => (/* binding */ DOWNLOADING_DATA_SUCCESS),
/* harmony export */   "V3": () => (/* binding */ DOWNLOADING_DATA_FAILURE),
/* harmony export */   "bB": () => (/* binding */ CREATING_PLAYLIST),
/* harmony export */   "ke": () => (/* binding */ CREATING_PLAYLIST_SUCCESS),
/* harmony export */   "ar": () => (/* binding */ CREATING_PLAYLIST_FAILURE),
/* harmony export */   "g$": () => (/* binding */ EDITING_PLAYLIST),
/* harmony export */   "G9": () => (/* binding */ EDITING_PLAYLIST_SUCCESS),
/* harmony export */   "sN": () => (/* binding */ EDITING_PLAYLIST_FAILURE),
/* harmony export */   "B1": () => (/* binding */ DELETING_PLAYLIST),
/* harmony export */   "vG": () => (/* binding */ DELETING_PLAYLIST_SUCCESS),
/* harmony export */   "IE": () => (/* binding */ DELETING_PLAYLIST_FAILURE)
/* harmony export */ });
const DOWNLOADING_DATA = "DOWNLOADING_DATA";
const DOWNLOADING_DATA_SUCCESS = "DOWNLOADING_DATA_SUCCESS";
const DOWNLOADING_DATA_FAILURE = "DOWNLOADING_DATA_FAILURE";
const CREATING_PLAYLIST = "CREATING_PLAYLIST";
const CREATING_PLAYLIST_SUCCESS = "CREATING_PLAYLIST_SUCCESS";
const CREATING_PLAYLIST_FAILURE = "CREATING_PLAYLIST_FAILURE";
const EDITING_PLAYLIST = "EDITING_PLAYLIST";
const EDITING_PLAYLIST_SUCCESS = "EDITING_PLAYLIST_SUCCESS";
const EDITING_PLAYLIST_FAILURE = "EDITING_PLAYLIST_FAILURE";
const DELETING_PLAYLIST = "DELETING_PLAYLIST";
const DELETING_PLAYLIST_SUCCESS = "DELETING_PLAYLIST_SUCCESS";
const DELETING_PLAYLIST_FAILURE = "DELETING_PLAYLIST_FAILURE";


/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6235));
module.exports = __webpack_exports__;

})();