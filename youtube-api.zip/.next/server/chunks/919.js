"use strict";
exports.id = 919;
exports.ids = [919];
exports.modules = {

/***/ 1801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WR": () => (/* binding */ DownloadUserData),
/* harmony export */   "Pn": () => (/* binding */ NewPlayList),
/* harmony export */   "_8": () => (/* binding */ EditPlaylist),
/* harmony export */   "c$": () => (/* binding */ DeletePlaylist)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types_typesYT__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4149);


const DownloadUserData = ()=>{
    return async (dispatch)=>{
        dispatch(downloadingData());
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get("/api/YoutubeApi/getYTData", {
                withCredentials: true
            });
            console.log(data);
            dispatch(downloadingDataSucess(data));
        } catch (err) {
            console.log(err);
            dispatch(downloadingFailure(err));
        }
    };
};
const downloadingData = ()=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DOWNLOADING_DATA */ .yY
    })
;
const downloadingDataSucess = (data)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DOWNLOADING_DATA_SUCCESS */ .u3,
        payload: data
    })
;
const downloadingFailure = (data)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DOWNLOADING_DATA_FAILURE */ .V3,
        payload: data
    })
;
const NewPlayList = (playlist)=>{
    return async (dispatch)=>{
        dispatch(creatingPlaylist());
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().get("/api/YoutubeApi/createPlayListYT", {
                withCredentials: true,
                params: {
                    title: playlist.title,
                    description: playlist.description,
                    privacyStatus: playlist.privacyStatus
                }
            });
            dispatch(creatingPlayListSucess(data));
        } catch (err) {
            console.log(err);
            dispatch(creatingPlaylistFailure(err));
        }
    };
};
const creatingPlaylist = ()=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .CREATING_PLAYLIST */ .bB
    })
;
const creatingPlayListSucess = (data)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .CREATING_PLAYLIST_SUCCESS */ .ke,
        payload: data
    })
;
const creatingPlaylistFailure = (err)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .CREATING_PLAYLIST_FAILURE */ .ar,
        payload: err
    })
;
const EditPlaylist = (playlist)=>{
    return async (dispatch)=>{
        dispatch(EditingPlaylist());
        try {
            await axios__WEBPACK_IMPORTED_MODULE_0___default().post("/api/YoutubeApi/updatePlaylistYT", {
                withCredentials: true,
                idPlaylist: playlist.id,
                title: playlist.title,
                description: playlist.description
            });
            dispatch(EditingPlaylistSucess());
        } catch (err) {
            console.log(err);
            dispatch(EditingPlaylistError(err));
        }
    };
};
const EditingPlaylist = ()=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .EDITING_PLAYLIST */ .g$
    })
;
const EditingPlaylistSucess = (data)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .EDITING_PLAYLIST_SUCCESS */ .G9
    })
;
const EditingPlaylistError = (err)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .EDITING_PLAYLIST_FAILURE */ .sN,
        payload: err
    })
;
const DeletePlaylist = (id)=>{
    return async (dispatch)=>{
        dispatch(deletingPlaylist());
        try {
            await axios__WEBPACK_IMPORTED_MODULE_0___default().post("/api/YoutubeApi/deletePlaylistYT", {
                withCredentials: true,
                idPlaylist: id
            });
            dispatch(deletePlaylistSuccess(id));
        } catch (err) {
            console.log(err);
            dispatch(deletePlaylistError(err));
        }
    };
};
const deletingPlaylist = ()=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DELETING_PLAYLIST */ .B1
    })
;
const deletePlaylistSuccess = (id)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DELETING_PLAYLIST_SUCCESS */ .vG,
        payload: id
    })
;
const deletePlaylistError = (err)=>({
        type: _types_typesYT__WEBPACK_IMPORTED_MODULE_1__/* .DELETING_PLAYLIST_FAILURE */ .IE,
        payload: err
    })
;


/***/ }),

/***/ 1549:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3196);
/* harmony import */ var _types_itemTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8374);
/* harmony import */ var _UpdatePlaylistModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1479);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_dnd__WEBPACK_IMPORTED_MODULE_4__]);
react_dnd__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ListPlaylist = ({ sub , actualPage  })=>{
    const { 0: edit , 1: setEdit  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [{ canDrop , isOver  }, drop] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_4__.useDrop)(()=>({
            accept: _types_itemTypes__WEBPACK_IMPORTED_MODULE_5__/* .itemTypes.BOX */ .c.BOX,
            drop: async (e)=>await axios__WEBPACK_IMPORTED_MODULE_2___default().post("/api/YoutubeApi/addYoutubeVideoPlaylist", {
                    withCredentials: true,
                    idPlaylist: sub.id,
                    idVideo: e.idVideo
                })
            ,
            collect: (monitor)=>({
                    isOver: monitor.isOver(),
                    canDrop: monitor.canDrop()
                })
        })
    );
    const isActive = canDrop && isOver;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
        className: "mb-2 flex justify-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: `/playlist/${sub.id}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: `w-100 inline-block text-white ${isActive && "text-green-500"} ${actualPage && "font-bold"}`,
                    ref: drop,
                    role: "boxVideos",
                    id: sub.id,
                    children: sub.snippet.title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>setEdit(true)
                    ,
                    children: "✏️"
                })
            }),
            edit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdatePlaylistModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                sub: sub,
                setEdit: setEdit,
                modal: edit,
                setModal: setEdit
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListPlaylist);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Loading = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-16 h-16 border-b-2 border-gray-900 rounded-full animate-spin",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "visually-hidden hidden",
            children: "Loading..."
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 6904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _actions_ActionsYT__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1801);




const NewPlayListModal = ({ modal , setModal  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { 0: playlist , 1: setPlaylist  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        title: "",
        description: "",
        privacyStatus: "public"
    });
    const createPlaylist = async ()=>{
        dispatch((0,_actions_ActionsYT__WEBPACK_IMPORTED_MODULE_3__/* .NewPlayList */ .Pn)(playlist));
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "defaultModal",
        "aria-hidden": "true",
        className: `${!modal && "hidden"} overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center h-modal md:h-full md:inset-0`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "relative px-4 w-full max-w-2xl h-full md:h-auto my-0 mx-auto mt-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative bg-blue-500 rounded-lg shadow-md",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between bg-blue-500 items-start p-5 rounded-t border-b dark:border-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-xl font-semibold text-gray-900 lg:text-2xl dark:text-white",
                                children: "Create new playlist"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "text-white bg-transparent rounded-lg text-sm p-1.5 ml-auto inline-flex items-center ",
                                "data-modal-toggle": "defaultModal",
                                onClick: ()=>setModal(false)
                                ,
                                children: "X"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "p-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "block text-gray-700 dark:text-white font-bold mb-2",
                                        htmlFor: "title",
                                        children: "Title"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: "bg-white appearance-none border-2 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-600",
                                        id: "title",
                                        type: "text",
                                        placeholder: "Playlist Title",
                                        value: playlist.title,
                                        onChange: (e)=>setPlaylist({
                                                ...playlist,
                                                title: e.target.value
                                            })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "block text-gray-700 dark:text-white font-bold mb-2",
                                        htmlFor: "description",
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        className: "bg-white appearance-none border-2 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-600",
                                        id: "description",
                                        type: "text",
                                        placeholder: "Playlist Description",
                                        value: playlist.description,
                                        onChange: (e)=>setPlaylist({
                                                ...playlist,
                                                description: e.target.value
                                            })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "block text-gray-700 dark:text-white font-bold mb-2",
                                        htmlFor: "privacyStatus",
                                        children: "Privacy Status"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "bg-white appearance-none border-2 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-600",
                                        id: "privacyStatus",
                                        type: "text",
                                        placeholder: "Privacy Status",
                                        value: playlist.privacyStatus,
                                        onChange: (e)=>setPlaylist({
                                                ...playlist,
                                                privacyStatus: e.target.value
                                            })
                                        ,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "public",
                                                children: "Public"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "private",
                                                children: "Private"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-end p-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "button",
                            className: "bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                            onClick: createPlaylist,
                            children: "Create Playlist"
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewPlayListModal);


/***/ }),

/***/ 5262:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PlayListHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SearchXscroll__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5267);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SearchXscroll__WEBPACK_IMPORTED_MODULE_1__]);
_SearchXscroll__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function PlayListHome() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchXscroll__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9367:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);



const PreviewVideo = ({ title , url , id: id1 , setLoading , videos  })=>{
    const deleteVideoFromPlaylist = async (id)=>{
        setLoading(true);
        await axios__WEBPACK_IMPORTED_MODULE_2___default().post("/api/YoutubeApi/deleteVideoFromPlaylist", {
            withCredentials: true,
            idVideo: id
        });
        //remove video from array
        const index = videos.findIndex((video)=>video.id === id
        );
        videos.splice(index, 1);
        setLoading(false);
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-[250px] m-5 hover:bg-gray-200 p-2 flex flex-col rounded-lg relative group ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "mb-4 mt-4 font-bold",
                children: title
            }),
            url ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                alt: title,
                src: url,
                width: 480,
                height: 360,
                className: "object-cover w-100 h-100 rounded-lg"
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: (e)=>deleteVideoFromPlaylist(e.target.id)
                ,
                id: id1,
                className: "bg-red-500 hover:bg-transparent border-solid hover:bg-red-700 text-white font-bold py-2 px-1 rounded cursor-pointer w-[200px] opacity-0 pointer-events-none mt-2 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 group-hover:opacity-100 group-hover:pointer-events-auto",
                children: "Delete from the playlist"
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PreviewVideo);


/***/ }),

/***/ 9704:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3196);
/* harmony import */ var _types_itemTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8374);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2076);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_tooltip__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_dnd__WEBPACK_IMPORTED_MODULE_1__]);
react_dnd__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const PreviewVideo = ({ title , url , video  })=>{
    const [{ isDragging  }, drag] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_1__.useDrag)(()=>({
            type: _types_itemTypes__WEBPACK_IMPORTED_MODULE_2__/* .itemTypes.BOX */ .c.BOX,
            item: {
                idVideo: video.id.videoId,
                video: video
            },
            end: (item, monitor)=>{
                const dropResult = monitor.getDropResult();
                if (item && dropResult) {}
            },
            collect: (monitor)=>({
                    isDragging: monitor.isDragging(),
                    handlerId: monitor.getHandlerId()
                })
        })
    );
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ref: drag,
        role: "Box",
        "data-testid": `box-${title}`,
        className: `${isDragging ? "border-blue-500 cursor-grabbing" : "\tborder-transparent cursor-grab\t"} border w-[250px] m-5 hover:bg-gray-200 flex flex-col rounded-lg p-3 shadow-lg`,
        "data-tip": "You can grab the video and drop it into a playlist.",
        children: [
            url ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                alt: title,
                src: url,
                width: 480,
                height: 360,
                className: "object-cover w-100 h-100 rounded-lg"
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "mb-4 mt-4 font-bold",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_tooltip__WEBPACK_IMPORTED_MODULE_4___default()), {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PreviewVideo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8587:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9704);
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__]);
_PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Search = ()=>{
    const { 0: search , 1: setSearch  } = useState("");
    const { 0: searching , 1: setSearching  } = useState(false);
    const { 0: results , 1: setResults  } = useState([]);
    useEffect(()=>{
        const getYTData = async ()=>{
            if (searching) {
                try {
                    const { data  } = await axios.post("/api/YoutubeApi/getVideosYT", {
                        withCredentials: true,
                        qSearch: search
                    });
                    setSearching(false);
                    setResults(data);
                } catch (err) {
                    console.log(err);
                }
            }
        };
        getYTData();
    }, [
        searching,
        search
    ]);
    return(/*#__PURE__*/ _jsxs("section", {
        className: "mt-5",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "flex justify-center items-center",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "relative mr-6 my-2",
                        children: /*#__PURE__*/ _jsx("input", {
                            type: "search",
                            className: "bg-purple-white shadow rounded border-0 p-3",
                            placeholder: "Search by name...",
                            value: search,
                            onChange: (e)=>setSearch(e.target.value)
                            ,
                            onKeyDown: (e)=>e.code === "Enter" && setSearching(true)
                        })
                    }),
                    /*#__PURE__*/ _jsx("button", {
                        className: "bg-blue-500 border-solid hover:bg-blue-700 text-white font-bold px-4 min-h-[48px] rounded cursor-pointer",
                        onClick: ()=>setSearching(true)
                        ,
                        children: "Search Video"
                    })
                ]
            }),
            searching ? /*#__PURE__*/ _jsx("div", {
                className: "flex justify-center mr-[10vw] mt-5",
                children: /*#__PURE__*/ _jsx(Loading, {})
            }) : /*#__PURE__*/ _jsxs("div", {
                className: "pl-10",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "titulo-search flex items-center justify-start flex-wrap",
                        children: /*#__PURE__*/ _jsx("h2", {
                            className: `ml-7 font-bold text-xl ${results.length <= 0 && "hidden"}`,
                            children: "SEARCH RESULTS:"
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "flex",
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "flex items-baseline justify-center flex-wrap",
                            children: results.length > 0 && (results === null || results === void 0 ? void 0 : results.map((sub)=>{
                                var ref, ref1, ref2;
                                /*#__PURE__*/ return _jsx(PreviewVideoFounded, {
                                    title: sub.snippet.title,
                                    url: (ref = sub.snippet) === null || ref === void 0 ? void 0 : (ref1 = ref.thumbnails) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.high) === null || ref2 === void 0 ? void 0 : ref2.url,
                                    video: sub
                                }, sub.id.videoId + sub.snippet.title);
                            }))
                        })
                    })
                ]
            })
        ]
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Search)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5267:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9704);
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__]);
_PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const SearchXscroll = ({ indexPage  })=>{
    const { 0: search , 1: setSearch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: searching , 1: setSearching  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: results , 1: setResults  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const tooltipMessage = indexPage ? "You can drag and drop the videos you want into the list you want, by their name in the sidebar or in the playlist box below" : "You can drag and drop the videos you want into the list you want, by their name in the sidebar.";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const getYTData = async ()=>{
            if (searching) {
                try {
                    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post("/api/YoutubeApi/getVideosYT", {
                        withCredentials: true,
                        qSearch: search
                    });
                    setSearching(false);
                    setResults(data);
                } catch (err) {
                    console.log(err);
                }
            }
        };
        getYTData();
    }, [
        searching,
        search
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "mt-5 max-w-[90%] my-0 mx-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                className: "flex justify-center items-center field-input",
                children: [
                    results.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "self bg-gray-600 rounded-full h-[20px] w-[20px] relative right-5 shadow-md hover:bg-gray-900",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xl text-white absolute top-[-5px] left-[7px] right-0 bottom-0",
                            "data-tip": tooltipMessage,
                            children: "!"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative mr-6 my-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "search",
                            className: "bg-purple-white shadow rounded border-0 p-3",
                            placeholder: "Search by name...",
                            value: search,
                            onChange: (e)=>setSearch(e.target.value)
                            ,
                            onKeyDown: (e)=>e.code === "Enter" && setSearching(true)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "bg-blue-500 border-solid hover:bg-blue-700 text-white font-bold px-4 min-h-[48px] rounded cursor-pointer",
                        onClick: (e)=>{
                            e.preventDefault(), setSearching(true);
                        },
                        children: "Search Video"
                    })
                ]
            }),
            searching ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center mr-[10vw] mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "titulo-search flex items-center justify-start flex-wrap",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: `ml-7 font-bold text-xl ${results.length <= 0 && "hidden"}`,
                            children: "SEARCH RESULTS:"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-baseline justify-center flex-wrap overflow-y-scroll max-h-[350px]",
                        children: results.length > 0 && (results === null || results === void 0 ? void 0 : results.map((sub)=>{
                            var ref, ref1, ref2;
                            /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PreviewVideoFounded__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                title: sub.snippet.title,
                                url: (ref = sub.snippet) === null || ref === void 0 ? void 0 : (ref1 = ref.thumbnails) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.high) === null || ref2 === void 0 ? void 0 : ref2.url,
                                video: sub
                            }, sub.etag);
                        }))
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchXscroll);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_ActionsYT__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1801);





const NewPlayListModal = ({ modal , setModal , sub  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const { 0: playlist , 1: setPlaylist  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        title: sub.snippet.title,
        description: sub.snippet.description,
        id: sub.id
    });
    const updatePlaylist = async ()=>{
        dispatch((0,_actions_ActionsYT__WEBPACK_IMPORTED_MODULE_4__/* .EditPlaylist */ ._8)(playlist));
        sub.snippet.title = playlist.title;
        setModal(false);
    };
    const deletePlaylist = async ()=>{
        dispatch((0,_actions_ActionsYT__WEBPACK_IMPORTED_MODULE_4__/* .DeletePlaylist */ .c$)(sub.id));
        setModal(false);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "defaultModal",
        "aria-hidden": "true",
        className: `${!modal && "hidden"} overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center h-modal md:h-full md:inset-0`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "relative px-4 w-full max-w-2xl h-full md:h-auto my-0 mx-auto mt-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative bg-blue-500 rounded-lg shadow-md",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between bg-blue-500 items-start p-5 rounded-t border-b dark:border-white",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                className: "text-xl font-semibold text-gray-900 lg:text-2xl dark:text-white",
                                children: [
                                    "Editing playlist ",
                                    sub.snippet.title
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "text-white bg-transparent rounded-lg text-sm p-1.5 ml-auto inline-flex items-center ",
                                "data-modal-toggle": "defaultModal",
                                onClick: ()=>setModal(false)
                                ,
                                children: "X"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "p-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "block text-gray-700 dark:text-white font-bold mb-2",
                                        htmlFor: "title",
                                        children: "Title"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: "bg-white appearance-none border-2 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-600",
                                        id: "title",
                                        type: "text",
                                        placeholder: "Playlist Title",
                                        value: playlist.title,
                                        onChange: (e)=>setPlaylist({
                                                ...playlist,
                                                title: e.target.value
                                            })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "block text-gray-700 dark:text-white font-bold mb-2",
                                        htmlFor: "description",
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        className: "bg-white appearance-none border-2 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-600",
                                        id: "description",
                                        type: "text",
                                        placeholder: "Playlist Description",
                                        value: playlist.description,
                                        onChange: (e)=>setPlaylist({
                                                ...playlist,
                                                description: e.target.value
                                            })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between p-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                                onClick: deletePlaylist,
                                children: "Delete Playlist"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline",
                                onClick: updatePlaylist,
                                children: "Update Playlist"
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewPlayListModal);


/***/ }),

/***/ 6604:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3196);
/* harmony import */ var _types_itemTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8374);
/* harmony import */ var _PreviewVideo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9367);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_dnd__WEBPACK_IMPORTED_MODULE_2__]);
react_dnd__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const BoxVideosPlaylist = ({ videos , idPlaylist , setLoading  })=>{
    const [{ canDrop  }, drop] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_2__.useDrop)(()=>({
            accept: _types_itemTypes__WEBPACK_IMPORTED_MODULE_3__/* .itemTypes.BOX */ .c.BOX,
            drop: async (e)=>(setLoading(true), await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/api/YoutubeApi/addYoutubeVideoPlaylist", {
                    withCredentials: true,
                    idPlaylist: idPlaylist,
                    idVideo: e.idVideo
                }), videos.push(e.video), setLoading(false))
            ,
            collect: (monitor)=>({
                    isOver: monitor.isOver(),
                    canDrop: monitor.canDrop()
                })
        })
    , [
        idPlaylist,
        setLoading
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        ref: drop,
        role: "boxVideos",
        className: ` ${canDrop ? "border-blue-500  " : "rounded-lg  "} border flex items-end justify-center flex-wrap rounded-lg w-[95%] my-0 mx-auto mb-5 min-h-[250px]`,
        children: videos.length > 0 && (videos === null || videos === void 0 ? void 0 : videos.map((sub)=>{
            var ref, ref1, ref2;
            /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PreviewVideo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: sub.snippet.title,
                url: (ref = sub.snippet) === null || ref === void 0 ? void 0 : (ref1 = ref.thumbnails) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.high) === null || ref2 === void 0 ? void 0 : ref2.url,
                id: sub.id,
                videos: videos,
                setLoading: setLoading
            }, sub.id);
        }))
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BoxVideosPlaylist);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);


const Footer = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "bg-blue-500 p-5",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-between items-center ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: "text-white text-lg font-bold",
                        children: "Playlist Manager"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    href: "/privacyPolicy",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: "text-white text-lg font-bold",
                        children: "Privacy Policy"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 8440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./public/images/logo-380x98.png
/* harmony default export */ const logo_380x98 = ({"src":"/_next/static/media/logo-380x98.60eeba35.png","height":98,"width":380,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAAKklEQVR42mNgCGKQYJBjMGXQZAhlMGVwZWAIYxBlsGawYPBmMGewZvACADi3A5sPHzVQAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./components/layout/Header.js






const Header = ()=>{
    const { data: session  } = (0,react_.useSession)();
    const router = (0,router_.useRouter)();
    return(/*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: "bg-blue-500 p-5",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between items-center ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "text-white text-lg font-bold max-w-[250px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: logo_380x98,
                                    alt: "Vix vixLogo",
                                    priority: true
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex items-center ml-10 font-bold",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white",
                                children: "Playlist management on steroids"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "",
                    children: session ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>(0,react_.signOut)("google")
                        ,
                        className: "bg-red-500 hover:bg-transparent border-solid hover:bg-red-700 text-white font-bold py-2 px-4 rounded cursor-pointer",
                        children: "Log out"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: "/login",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `bg-blue-600 hover:bg-transparent border-solid	 hover:bg-blue-800  text-white font-bold 
              py-2 px-4 rounded cursor-pointer ${router.asPath === "/login" && "hidden"}`,
                            children: "Login"
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const layout_Header = (Header);


/***/ }),

/***/ 838:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3196);
/* harmony import */ var react_dnd_touch_backend__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9238);
/* harmony import */ var react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1152);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4780);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8440);
/* harmony import */ var _SideBarList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6927);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3529);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_dnd__WEBPACK_IMPORTED_MODULE_3__, react_dnd_touch_backend__WEBPACK_IMPORTED_MODULE_4__, react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_5__, _SideBarList__WEBPACK_IMPORTED_MODULE_8__]);
([react_dnd__WEBPACK_IMPORTED_MODULE_3__, react_dnd_touch_backend__WEBPACK_IMPORTED_MODULE_4__, react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_5__, _SideBarList__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Layout = ({ children  })=>{
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.useSession)();
    let isTablet;
    if (false) {}
    const backend = isTablet ? react_dnd_touch_backend__WEBPACK_IMPORTED_MODULE_4__.TouchBackend : react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_5__.HTML5Backend;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_6___default()), {
                async: true,
                src: "https://www.googletagmanager.com/gtag/js?id=UA-28434234-61"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_6___default()), {
                id: "google-analytics",
                strategy: "afterInteractive",
                children: `
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         
         gtag('config', 'UA-28434234-61');
        `
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Playlist Manager"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1.0, width=device-width"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Playlist vixfid"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "playlist, youtube, music, vixfid"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "author",
                        content: "Gabriel Dos Santos with vixfid"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_dnd__WEBPACK_IMPORTED_MODULE_3__.DndProvider, {
                backend: backend,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                    className: "flex row min-h-screen max-w-[95%]",
                    children: [
                        session && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SideBarList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[100%]",
                            children: children
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3196);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ListPlaylist__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1549);
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4461);
/* harmony import */ var _NewPlayListModal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6904);
/* harmony import */ var _types_itemTypes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8374);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_dnd__WEBPACK_IMPORTED_MODULE_2__, _ListPlaylist__WEBPACK_IMPORTED_MODULE_5__]);
([react_dnd__WEBPACK_IMPORTED_MODULE_2__, _ListPlaylist__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const SideBarList = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { playLists , loading  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.youtubeApi
    );
    const { 0: modal , 1: setModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: subsList , 1: setSubsList  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [{ canDrop  }] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_2__.useDrop)(()=>({
            accept: _types_itemTypes__WEBPACK_IMPORTED_MODULE_8__/* .itemTypes.BOX */ .c.BOX,
            collect: (monitor)=>({
                    isOver: monitor.isOver(),
                    canDrop: monitor.canDrop()
                })
        })
    );
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
        className: `p-5 pb-5 min-w-[188px] ${!canDrop ? "bg-blue-500" : "bg-blue-600"}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "hover:bg-blue-700 border-solid bg-blue-600 text-white font-bold px-2 min-h-[48px] rounded cursor-pointer mb-5",
                onClick: ()=>setModal(true)
                ,
                children: "Create a playlist"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "h-[435px] max-h-[435px] overflow-hidden overflow-y-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "mb-5 text-white font-bold",
                        children: "PLAYLISTS:"
                    }),
                    loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "ml-[10px]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loading__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    }) : playLists.map((sub)=>{
                        /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ListPlaylist__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            sub: sub,
                            actualPage: (router === null || router === void 0 ? void 0 : router.query.id) === sub.id && true
                        }, sub.id);
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NewPlayListModal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                modal: modal,
                setModal: setModal
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideBarList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2919:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ar": () => (/* reexport safe */ _layout_Layout__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "Y4": () => (/* reexport safe */ _SearchXscroll__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "gb": () => (/* reexport safe */ _Loading__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "cf": () => (/* reexport safe */ _boxVideosPlaylist__WEBPACK_IMPORTED_MODULE_6__.Z)
/* harmony export */ });
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(838);
/* harmony import */ var _PlayListHome__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5262);
/* harmony import */ var _PreviewVideo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9367);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8587);
/* harmony import */ var _SearchXscroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5267);
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4461);
/* harmony import */ var _boxVideosPlaylist__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6604);
/* harmony import */ var _types_itemTypes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8374);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_Layout__WEBPACK_IMPORTED_MODULE_0__, _PlayListHome__WEBPACK_IMPORTED_MODULE_1__, _Search__WEBPACK_IMPORTED_MODULE_3__, _SearchXscroll__WEBPACK_IMPORTED_MODULE_4__, _boxVideosPlaylist__WEBPACK_IMPORTED_MODULE_6__]);
([_layout_Layout__WEBPACK_IMPORTED_MODULE_0__, _PlayListHome__WEBPACK_IMPORTED_MODULE_1__, _Search__WEBPACK_IMPORTED_MODULE_3__, _SearchXscroll__WEBPACK_IMPORTED_MODULE_4__, _boxVideosPlaylist__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ itemTypes)
/* harmony export */ });
const itemTypes = {
    BOX: 'box'
};


/***/ }),

/***/ 4149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yY": () => (/* binding */ DOWNLOADING_DATA),
/* harmony export */   "u3": () => (/* binding */ DOWNLOADING_DATA_SUCCESS),
/* harmony export */   "V3": () => (/* binding */ DOWNLOADING_DATA_FAILURE),
/* harmony export */   "bB": () => (/* binding */ CREATING_PLAYLIST),
/* harmony export */   "ke": () => (/* binding */ CREATING_PLAYLIST_SUCCESS),
/* harmony export */   "ar": () => (/* binding */ CREATING_PLAYLIST_FAILURE),
/* harmony export */   "g$": () => (/* binding */ EDITING_PLAYLIST),
/* harmony export */   "G9": () => (/* binding */ EDITING_PLAYLIST_SUCCESS),
/* harmony export */   "sN": () => (/* binding */ EDITING_PLAYLIST_FAILURE),
/* harmony export */   "B1": () => (/* binding */ DELETING_PLAYLIST),
/* harmony export */   "vG": () => (/* binding */ DELETING_PLAYLIST_SUCCESS),
/* harmony export */   "IE": () => (/* binding */ DELETING_PLAYLIST_FAILURE)
/* harmony export */ });
const DOWNLOADING_DATA = "DOWNLOADING_DATA";
const DOWNLOADING_DATA_SUCCESS = "DOWNLOADING_DATA_SUCCESS";
const DOWNLOADING_DATA_FAILURE = "DOWNLOADING_DATA_FAILURE";
const CREATING_PLAYLIST = "CREATING_PLAYLIST";
const CREATING_PLAYLIST_SUCCESS = "CREATING_PLAYLIST_SUCCESS";
const CREATING_PLAYLIST_FAILURE = "CREATING_PLAYLIST_FAILURE";
const EDITING_PLAYLIST = "EDITING_PLAYLIST";
const EDITING_PLAYLIST_SUCCESS = "EDITING_PLAYLIST_SUCCESS";
const EDITING_PLAYLIST_FAILURE = "EDITING_PLAYLIST_FAILURE";
const DELETING_PLAYLIST = "DELETING_PLAYLIST";
const DELETING_PLAYLIST_SUCCESS = "DELETING_PLAYLIST_SUCCESS";
const DELETING_PLAYLIST_FAILURE = "DELETING_PLAYLIST_FAILURE";


/***/ })

};
;