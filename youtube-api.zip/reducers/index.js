import { combineReducers } from 'redux'

import youtubeApi from './youtubeApi'

const rootReducer = combineReducers({

  youtubeApi,

})

export default rootReducer